import type { ICvorZaCitanje, ICvorZaUpis } from "./CvorOperacije";
import type { ICvorZaZivotniCiklus } from "./CvorCiklus";
import type { Vrednost } from "./Vrednost";

export type ICvorPodataka = ICvorZaCitanje & ICvorZaUpis & ICvorZaZivotniCiklus & {
    readonly podaci: Readonly<Record<string, Vrednost>>;
    readonly verzija: Readonly<Record<string, number>>;
  };