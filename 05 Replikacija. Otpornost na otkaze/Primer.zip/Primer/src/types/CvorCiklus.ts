export type ICvorZaZivotniCiklus = {
  readonly idCvora: string;
  readonly ziv: boolean;
  ugasi(): void;
  oporavi(): void;
};