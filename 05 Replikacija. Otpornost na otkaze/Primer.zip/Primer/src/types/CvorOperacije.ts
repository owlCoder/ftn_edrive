import type { OdgovorCitanja } from "./OdgovorCitanja";
import type { Vrednost } from "./Vrednost";

export type ICvorZaCitanje = {
  procitaj(kljuc: string): OdgovorCitanja;
};

export type ICvorZaUpis = {
  upisi(kljuc: string, vrednost: Vrednost, verzija: number): boolean;
};
