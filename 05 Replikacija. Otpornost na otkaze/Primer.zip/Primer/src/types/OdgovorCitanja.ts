import type { Vrednost } from "./Vrednost";

export type OdgovorCitanja = [Vrednost, number] | null;