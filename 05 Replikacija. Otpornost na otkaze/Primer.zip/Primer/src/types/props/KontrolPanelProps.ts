export type KontrolePanelProps = {
  onUpisi: (kljuc: string, vrednost: string) => void;
  onProcitaj: (kljuc: string) => void;
};