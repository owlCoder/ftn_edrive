export type LogPanelProps = {
  logovi: string[];
};