import type { ICvorPodataka } from "../CvorPodataka";

export type KarticaCvoraProps = {
  cvor: ICvorPodataka;
  onUgasi: (id: string) => void;
  onOporavi: (id: string) => void;
};
