import { useCallback, useState } from "react";
import type { Vrednost } from "../../types/Vrednost";
import { napraviSkladiste } from "../../utils/PraznoSkladisteHelper";
import { KvorumStrategijaService } from "../../Services/skladiste/KvorumStrategijaSkladisteService";

export function useDistribuiranoSkladiste() {
  const [{ skladiste, cvorovi }, setSt] = useState(() =>
    napraviSkladiste(6, 3, 3, new KvorumStrategijaService()),
  );
  const [logovi, setLogovi] = useState<string[]>([]);

  const osvezi = useCallback(() => setSt((prev) => ({ ...prev })), []);
  const dodajLog = useCallback(
    (poruka: string) => setLogovi((l) => [...l, poruka]),
    [],
  );

  const akcijaUpis = useCallback(
    (kljuc: string, vrednost: Vrednost) => {
      const uspeh = skladiste.upisi(kljuc, vrednost);
      dodajLog(
        `UPIS(${kljuc}, ${vrednost}) -> ${uspeh ? "uspesno" : "neuspesno"}`,
      );
      osvezi();
    },
    [skladiste, dodajLog, osvezi],
  );

  const akcijaCitanje = useCallback(
    (kljuc: string) => {
      const rez = skladiste.procitaj(kljuc);
      dodajLog(`CITANJE(${kljuc}) -> ${rez ?? "null (kvorum nije dostignut)"}`);
      osvezi();
    },
    [skladiste, dodajLog, osvezi],
  );

  const ugasiCvor = useCallback(
    (id: string) => {
      cvorovi.find((c) => c.idCvora === id)?.ugasi();
      dodajLog(`[!] Cvor ${id} je u ispadu`);
      osvezi();
    },
    [cvorovi, dodajLog, osvezi],
  );

  const oporaviCvor = useCallback(
    (id: string) => {
      cvorovi.find((c) => c.idCvora === id)?.oporavi();
      dodajLog(`[+] Cvor ${id} je oporavljen`);
      osvezi();
    },
    [cvorovi, dodajLog, osvezi],
  );

  return { cvorovi, logovi, akcijaUpis, akcijaCitanje, ugasiCvor, oporaviCvor };
}
