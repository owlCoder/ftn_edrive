import { KarticaCvora } from "../../components/CvorCard/CvorCard";
import { KontrolniPanel } from "../../components/KontrolniPanel/KontrolniPanel";
import { LogPanel } from "../../components/LogPanel/LogPanel";
import { useDistribuiranoSkladiste } from "../../hooks/skladiste/useSkladisteHook";

export const PocetnaStranica = () => {
  const { cvorovi, logovi, akcijaUpis, akcijaCitanje, ugasiCvor, oporaviCvor } =
    useDistribuiranoSkladiste();
  return (
    <>
      <div className="aplikacija">
        <div className="sadrzaj">
          <div className="header">
            <h1 className="naslov-glavny">Distribuirano skladište podataka</h1>
            <p className="podnaslov">
              Kvorum replikacija · W=3 · R=3 · 6 čvorova
            </p>
          </div>

          <section className="opis">
            <p>
              Aplikacija simulira distribuirano skladište podataka sa{" "}
              <b>kvorum replikacijom</b>. Podaci se čuvaju na više čvorova
              (replika), a svaka operacija upisa i čitanja koristi pravila
              kvoruma definisana parametrima <b>W (write kvorum)</b> i{" "}
              <b>R (read kvorum)</b>.
            </p>
            <p>
              Kada se izvrši upis, vrednost se šalje svim aktivnim čvorovima
              zajedno sa novom verzijom podatka. Upis je uspešan samo ako
              najmanje W ćvorova potvrdi prijem podatka. Na ovaj način se
              obezbeđuje otpornost na otkaze pojedinih čvorova.
            </p>
            <p>
              Prilikom čitanja, aplikacija prikuplja odgovore sa aktivnih
              čvorova i bira vrednost sa najvećom verzijom, što predstavlja
              najnovije stanje sistema. Čitanje je uspešno samo ako je dostupno
              najmanje R odgovora.
            </p>
            <p>
              Svaki čvor može biti aktivan ili u stanju otkaza. Dugmići "Ugasi" i
              "Oporavi" omogućavaju simulaciju pada i povratka cvorova, kako bi
              se pokazalo kako kvorum mehanizam obezbeđuje{" "}
              <b>konzistentnost</b> i <b>dostupnost</b> podataka čak i pri{" "}
              <b>delimičnim otkazima sistema</b>.
            </p>
          </section>

          <KontrolniPanel onUpisi={akcijaUpis} onProcitaj={akcijaCitanje} />

          <div className="mreza-cvorova">
            {cvorovi.map((cvor) => (
              <KarticaCvora
                key={cvor.idCvora}
                cvor={cvor}
                onUgasi={ugasiCvor}
                onOporavi={oporaviCvor}
              />
            ))}
          </div>

          <LogPanel logovi={logovi} />
        </div>
      </div>
    </>
  );
};
