import type { IStrategijaService } from "../../Domain/services/skladiste/IStrategijaSkladisteService";
import type { Vrednost } from "../../types/Vrednost";

export class KvorumStrategijaService implements IStrategijaService {
  izaberiVrednost(odgovori: [Vrednost, number][]): Vrednost {
    return odgovori.reduce((maks, tek) => (tek[1] > maks[1] ? tek : maks))[0];
  }
}