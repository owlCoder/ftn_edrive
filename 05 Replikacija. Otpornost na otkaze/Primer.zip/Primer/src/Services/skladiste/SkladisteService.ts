import type { IStrategijaService } from "../../Domain/services/skladiste/IStrategijaSkladisteService";
import type { ISkladisteService } from "../../Domain/services/skladiste/ISkladisteService";
import type { ICvorPodataka } from "../../types/CvorPodataka";
import type { Vrednost } from "../../types/Vrednost";

export class SkladisteService implements ISkladisteService {
  private verzijaKljuceva: Record<string, number> = {};
  private readonly cvorovi: ICvorPodataka[];
  private readonly W: number;
  private readonly R: number;
  private readonly strategija: IStrategijaService;

  constructor(c: ICvorPodataka[], w: number, r: number, s: IStrategijaService) {
    this.cvorovi = c;
    this.W = w;
    this.R = r;
    this.strategija = s;
  }

  upisi(kljuc: string, vrednost: Vrednost): boolean {
    this.verzijaKljuceva[kljuc] = (this.verzijaKljuceva[kljuc] ?? 0) + 1;
    const verzija = this.verzijaKljuceva[kljuc];
    const uspesno = this.cvorovi.filter((c) =>
      c.upisi(kljuc, vrednost, verzija),
    ).length;
    return uspesno >= this.W;
  }

  procitaj(kljuc: string): Vrednost | null {
    const odgovori = this.cvorovi
      .map((c) => c.procitaj(kljuc))
      .filter((o): o is [Vrednost, number] => o !== null);
    if (odgovori.length < this.R) return null;
    return this.strategija.izaberiVrednost(odgovori);
  }
}
