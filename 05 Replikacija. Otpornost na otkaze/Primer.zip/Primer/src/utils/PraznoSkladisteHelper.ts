import { CvorPodataka } from "../Domain/models/CvorPodataka";
import type { ISkladisteService } from "../Domain/services/skladiste/ISkladisteService";
import type { IStrategijaService } from "../Domain/services/skladiste/IStrategijaSkladisteService";
import { SkladisteService } from "../Services/skladiste/SkladisteService";
import type { ICvorPodataka } from "../types/CvorPodataka";

export function napraviSkladiste(brojCvorova: number = 5, W: number = 3, R: number = 3, s: IStrategijaService) : { skladiste: ISkladisteService; cvorovi: ICvorPodataka[] } {
  const cvorovi: ICvorPodataka[] = Array.from({ length: brojCvorova }, (_, i) => new CvorPodataka(`C${i + 1}`));
  return { skladiste: new SkladisteService(cvorovi, W, R, s), cvorovi };
}
