import { useState } from "react";
import type { KontrolePanelProps } from "../../types/props/KontrolPanelProps";

export function KontrolniPanel({ onUpisi, onProcitaj }: KontrolePanelProps) {
  const [kljuc, setKljuc] = useState("");
  const [vrednost, setVrednost] = useState("");

  return (
    <div className="kontrole">
      <input
        className="unos"
        value={kljuc}
        onChange={(e) => setKljuc(e.target.value)}
        placeholder="Unesi ključ"
      />
      <input
        className="unos"
        value={vrednost}
        onChange={(e) => setVrednost(e.target.value)}
        placeholder="Unesi vrednost"
      />
      <button className="dugme" onClick={() => onUpisi(kljuc, vrednost)}>
        Upiši
      </button>
      <button className="dugme citaj" onClick={() => onProcitaj(kljuc)}>
        Pročitaj
      </button>
    </div>
  );
}
