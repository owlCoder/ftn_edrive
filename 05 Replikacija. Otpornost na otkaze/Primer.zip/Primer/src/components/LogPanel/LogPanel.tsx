import type { LogPanelProps } from "../../types/props/LogPanelProps";

export function LogPanel({ logovi }: LogPanelProps) {
  return (
    <div className="log-sekcija">
      <p className="naslov-logova">Logovi</p>
      <pre className="log-kutija">
        {logovi.length ? (
          logovi.map((l: string, i: number) => <div key={i}>{l}</div>)
        ) : (
          <span className="log-prazan">// nema logova</span>
        )}
      </pre>
    </div>
  );
}