import type { KarticaCvoraProps } from "../../types/props/KarticaCvoraProps";

export function KarticaCvora({ cvor, onUgasi, onOporavi }: KarticaCvoraProps) {
  return (
    <div className={`kartica-cvora${cvor.ziv ? "" : " pao"}`}>
      <div className="kartica-header">
        <h3 className="naslov-cvora">{cvor.idCvora}</h3>
        <span className={`status-badge${cvor.ziv ? "" : " pao"}`}>
          {cvor.ziv ? "AKTIVAN" : "U ISPADU"}
        </span>
      </div>

      <div className="sekcija podaci">
        <p className="naslov-sekcije">Podaci</p>
        <pre>{JSON.stringify(cvor.podaci, null, 2) || "{}"}</pre>
      </div>

      <div className="sekcija verzije">
        <p className="naslov-sekcije">Verzije</p>
        <pre>{JSON.stringify(cvor.verzija, null, 2) || "{}"}</pre>
      </div>

      <div className="akcije-cvora">
        <button
          className="dugme-cvor ugasi"
          onClick={() => onUgasi(cvor.idCvora)}
          disabled={!cvor.ziv}
        >
          Ugasi
        </button>
        <button
          className="dugme-cvor oporavi"
          onClick={() => onOporavi(cvor.idCvora)}
          disabled={cvor.ziv}
        >
          Oporavi
        </button>
      </div>
    </div>
  );
}