import type { ICvorPodataka } from "../../types/CvorPodataka";
import type { OdgovorCitanja } from "../../types/OdgovorCitanja";
import type { Vrednost } from "../../types/Vrednost";

export class CvorPodataka implements ICvorPodataka {
  readonly idCvora: string;
  private _podaci: Record<string, Vrednost> = {};
  private _verzija: Record<string, number> = {};
  private _ziv = true;

  constructor(idCvora: string) {
    this.idCvora = idCvora;
  }

  get ziv() { return this._ziv; }
  get podaci(): Readonly<Record<string, Vrednost>> { return this._podaci; }
  get verzija(): Readonly<Record<string, number>> { return this._verzija; }
  ugasi(): void { this._ziv = false; }
  oporavi(): void { this._ziv = true; }

  upisi(kljuc: string, vrednost: Vrednost, verzija: number): boolean {
    if (!this.ziv) return false;
    this._podaci = { ...this._podaci, [kljuc]: vrednost };
    this._verzija = { ...this._verzija, [kljuc]: verzija };
    return true;
  }

  procitaj(kljuc: string): OdgovorCitanja {
    if (!this._ziv || !(kljuc in this._podaci)) return null;
    return [this._podaci[kljuc], this._verzija[kljuc]];
  }
}