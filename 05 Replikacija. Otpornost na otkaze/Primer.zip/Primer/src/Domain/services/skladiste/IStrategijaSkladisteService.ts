import type { Vrednost } from "../../../types/Vrednost";

export interface IStrategijaService {
  izaberiVrednost(odgovori: [Vrednost, number][]): Vrednost;
};