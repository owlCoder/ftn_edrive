import type { Vrednost } from "../../../types/Vrednost";

export type ISkladisteService = {
  upisi(kljuc: string, vrednost: Vrednost): boolean;
  procitaj(kljuc: string): Vrednost | null;
};