import { PocetnaStranica } from "./pages/PocetnaStranica/PocetnaStranica";

export default function App() {
  return <PocetnaStranica />;
}
